﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExemploMVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BlackController : ControllerBase
    {
        private int name;

        [Route("api/[controller]/jogada/{jogador}/{pontos]")]
        public JsonResult Jogada(int jogador, int pontos)
        {
            int x, total_pontos = 0;
            Random sorteio = new Random();
            x = sorteio.Next(1, 14);

            switch (x)
            {
                case 1: name = total_pontos += 1; break;
                case 2: name = total_pontos += 2; break;
                case 3: name = total_pontos += 3; break;
                case 4: name = total_pontos += 4; break;
                case 5: name = total_pontos += 5; break;
                case 6: name = total_pontos += 6; break;
                case 7: name = total_pontos += 7; break;
                case 8: name = total_pontos += 8; break;
                case 9: name = total_pontos += 9; break;
                case 10: name = total_pontos += 10; break;
                case 11: name = total_pontos += 11; break;
                case 12: name = total_pontos += 12; break;
                case 13: name = total_pontos += 13; break;
            }      
            if (jogador == 1)
            {
                var resultado_1 = pontos + total_pontos;
                var result = new
                {
                    carta = name,
                    pontos = resultado_1,
                    id = jogador
                };
                return Json(result);
            }
            else if (jogador == 2)
            {
                var resultado_2 = pontos + total_pontos;
                var result = new
                {
                    carta = name,
                    pontos = resultado_2,
                    id = jogador
                };
                return Json(result);
            }
        }
        private JsonResult Json(object result)
        {
            throw new NotImplementedException();
        }
    }
}
